BR Play
======================

![screenshot-01.jpg](https://github.com/olavopeixoto/plugin.video.brplay/raw/master/resources/screenshots/screenshot-01.jpg)

![screenshot-02.jpg](https://github.com/olavopeixoto/plugin.video.brplay/raw/master/resources/screenshots/screenshot-02.jpg)

![screenshot-03.jpg](https://github.com/olavopeixoto/plugin.video.brplay/raw/master/resources/screenshots/screenshot-03.jpg)

License
-------
This software is released under the [GPL 3.0 license] [1].
[1]: http://www.gnu.org/licenses/gpl-3.0.html
